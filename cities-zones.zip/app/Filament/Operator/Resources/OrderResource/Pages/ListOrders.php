<?php

namespace App\Filament\Operator\Resources\OrderResource\Pages;

use AlperenErsoy\FilamentExport\Actions\FilamentExportHeaderAction;
use App\Filament\Exports\OrderExporter;
use App\Filament\Imports\OrderImporter;
use App\Filament\Operator\Resources\OrderResource;
use Filament\Actions;
use Filament\Actions\ExportAction;
use Filament\Actions\ImportAction;
use Filament\Pages\Concerns\ExposesTableToWidgets;
use Filament\Resources\Components\Tab;

use Filament\Resources\Pages\ListRecords;

class ListOrders extends ListRecords
{
    use ExposesTableToWidgets;
    protected static string $resource = OrderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
            ImportAction::make()
                ->importer(OrderImporter::class),
            \pxlrbt\FilamentExcel\Actions\Pages\ExportAction::make(),

            // ExportAction::make()
            //     ->exporter(OrderExporter::class)
            

        ];
    }
    protected function getHeaderWidgets(): array
    {
        return OrderResource::getWidgets();
    }

    public function getTabs(): array
    {
        return [
            null => Tab::make('All'),
            'pending pickup' => Tab::make()->query(fn($query) => $query->where('order_status', 'pending pickup')),
            'picked up' => Tab::make()->query(fn($query) => $query->where('order_status', 'picked up')),
            'ready for delivery' => Tab::make()->query(fn($query) => $query->where('order_status', 'ready for delivery')),
            'out for delivery' => Tab::make()->query(fn($query) => $query->where('order_status', 'out for delivery')),
            'delivered' => Tab::make()->query(fn($query) => $query->where('order_status', 'delivered')),
            'returned' => Tab::make()->query(fn($query) => $query->where('order_status', 'returned')),
            'damaged' => Tab::make()->query(fn($query) => $query->where('order_status', 'damaged')),
        ];
    }
}
