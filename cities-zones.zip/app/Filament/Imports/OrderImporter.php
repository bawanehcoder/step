<?php

namespace App\Filament\Imports;

use App\Models\City;
use App\Models\Company;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Zone;
use Filament\Actions\Imports\ImportColumn;
use Filament\Actions\Imports\Importer;
use Filament\Actions\Imports\Models\Import;

class OrderImporter extends Importer
{
    protected static ?string $model = Order::class;

    public static function getColumns(): array
    {
        return [
            ImportColumn::make('customer_id')
                ->relationship(resolveUsing: function (string $state): ?Customer {
                    return Customer::query()
                        ->where('email', $state)
                        ->orWhere('name', $state)
                        ->orWhere('phone', $state)
                        ->first()->id ?? null;
                }),
            ImportColumn::make('city_id')
                ->relationship(resolveUsing: function (string $state): ?City {
                    return City::query()
                        ->where('name', $state)
                        ->orWhere('id', $state)
                        ->first()->id ?? null;
                }),
            ImportColumn::make('zone_id')
                ->relationship(resolveUsing: function (string $state): ?Zone {
                    return Zone::query()
                        ->where('name', $state)
                        ->orWhere('id', $state)
                        ->first()->id ?? null;
                }),
            ImportColumn::make('phone_number')
                ->rules(['max:255']),
            ImportColumn::make('cash_required')
                ->requiredMapping()
                ->numeric(),
            ImportColumn::make('invoice_number')
                ->requiredMapping(),
            ImportColumn::make('number_of_pieces')
                ->requiredMapping()
                ->numeric()
                ->rules(['integer']),
            ImportColumn::make('order_notes'),
        ];
    }

    public function importRow(array $row): void
    {
        // Debug information
        \Log::info('Importing row:', $row);
        
        // Import logic
        Order::create($row);
    }

    public static function getCompletedNotificationBody(Import $import): string
    {
        return 'Your order import has completed.';
    }
}
