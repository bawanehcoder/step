<?php

namespace App\Filament\Company\Resources\OrderResource\Pages;

use App\Events\OrderUpdated;
use App\Filament\Company\Resources\OrderResource;
use App\Models\OrderLog;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditOrder extends EditRecord
{
    protected static string $resource = OrderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            // Actions\DeleteAction::make(),
        ];
    }

    protected  function afterSave(): void
    {
        // event(new OrderUpdated($this->record));

        // dd($this->record);
        $record = $this->record;

        OrderLog::create([
            'barcode' => $record->barcode,
            'customer_id' => $record->customer_id,
            'order_type_id' => $record->order_type_id,
            'delivery_option' => $record->delivery_option,
            'custom_delivery_date' => $record->custom_delivery_date,
            'order_description' => $record->order_description,
            'weight' => $record->weight,
            'number_of_pieces' => $record->number_of_pieces,
            'invoice_number' => $record->invoice_number,
            'invoice_value' => $record->invoice_value,
            'cash_required' => $record->cash_required,
            'order_notes' => $record->order_notes,
            'order_status' => $record->order_status,
            'company_id' => $record->company_id,
            'order_id' => $record->id,
        ]);
    }
}
