<?php

namespace App\Imports;

use App\Models\City;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Zone;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ImportOrder implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        $company_id = 1;
        if (auth('companies')?->user()?->id) {
            $company_id = auth('companies')->user()->id;
        }

        $city_id = null;
        $city = $user = Customer::where('name', $row['city_id'])
            ->orWhere('id', $row['city_id'])
            ->first();

        if ($city) {
            $city_id = $city->id;
        } else {
            $city = City::create([
                'name' => $row['city_id'],
                'price' => 3,
            ]);
            $city_id = $city->id;

        }


        $zone_id = null;
        $zone = $user = Customer::where('name', $row['zone_id'])
            ->orWhere('id', $row['zone_id'])
            ->first();

        if ($zone) {
            $zone_id = $zone->id;
        } else {
            $zone = Zone::create([
                'name' => $row['zone_id'],
                'city_id' => $city_id,
                'price' => 3,
            ]);
            $zone_id = $zone->id;

        }





        $user_id = null;
        $user = Customer::where('id', $row['customer_id'])
            ->orWhere('name', $row['customer_id'])
            ->orWhere('phone', $row['customer_id'])->first();
            // dd( $user);

        if ($user) {
            $user_id = $user->id;
        } else {
            $user = Customer::create([
                'name' => $row['customer_id'],
                'phone' => $row['customer_id'],
                'company_id' => $company_id,
                'city_id' => $city_id,
                'zone_id' => $zone_id,
                'street_name' => $zone_id,
                'building_number' => $zone_id,
                'floor' => $zone_id,

            ]);
            $user_id = $user->id;
        }


        // dd($row);
        return new Order([
            'customer_id' => $user_id,
            'city_id' => $city_id,
            'zone_id' => $zone_id,
            'phone_number' => $row['phone_number'],
            'cash_required' => (double) $row['cash_required'],
            'invoice_number' => $row['invoice_number'],
            'number_of_pieces' => (int) $row['number_of_pieces'],
            'order_notes' => $row['order_notes'],
            'company_id' => $company_id,
        ]);
    }
}
